# Smart Clinic Management App - README

## Overview

Smart Clinic Management App is a comprehensive solution for doctors to handle appointments, patients, prescriptions, reports, and manage multiple clinics under one doctor profile. The app is built using Flutter and targets Android, iOS, and Windows Desktop platforms with Firebase as the backend.

## Key Features

- **Multi-Platform Support**: Works on Android, iOS, and Windows Desktop
- **Offline-First Architecture**: Use the app without internet connection
- **Automatic Sync**: Changes sync automatically when connection is restored
- **Multi-Clinic Management**: Manage multiple clinic locations under one account
- **Role-Based Access**: Different interfaces for doctors, nurses, receptionists, and pharmacists
- **Patient Database**: Store and manage patient profiles, medical history, allergies, medications, and attachments
- **Appointment Management**: Book, reschedule, and cancel appointments with calendar integration
- **Prescription System**: Generate, save, export, and print prescriptions
- **Reports & Referrals**: Create custom documents with clinic branding

## Getting Started

### Prerequisites

- Flutter SDK (latest stable version)
- Android Studio / Xcode / Visual Studio (depending on target platform)
- Firebase account

### Installation

1. Unzip the project files
2. Follow the Firebase configuration guide in `docs/firebase_configuration_guide.md`
3. Run `flutter pub get` to install dependencies
4. Run the app with `flutter run`

## Deployment

Detailed deployment guides are available in the docs folder:

- [Android Deployment Guide](docs/android_deployment_guide.md)
- [iOS Deployment Guide](docs/ios_deployment_guide.md)
- [Windows Deployment Guide](docs/windows_deployment_guide.md)
- [Firebase Configuration Guide](docs/firebase_configuration_guide.md)

## Project Structure

```
lib/
├── app/                  # App-wide configurations
│   ├── config/           # Firebase options, themes, etc.
│   └── router/           # Navigation routing
├── core/                 # Core utilities and constants
├── data/                 # Data layer
│   ├── models/           # Data models
│   ├── repositories/     # Repository implementations
│   └── services/         # Services (Isar, Sync, etc.)
├── domain/               # Domain layer
│   ├── entities/         # Business entities
│   └── repositories/     # Repository interfaces
└── presentation/         # UI layer
    ├── blocs/            # BLoC state management
    ├── screens/          # App screens
    └── widgets/          # Reusable UI components
```

## Offline-First Architecture

The app uses Isar database for local storage and implements a robust sync mechanism that:

1. Stores all data locally first
2. Queues changes when offline
3. Syncs automatically when connection is restored
4. Resolves conflicts using timestamp-based strategy

## Authentication

The app supports:
- Email/Password authentication
- Phone number authentication
- Biometric authentication on supported devices
- Optional Google sign-in

## Role-Based Access

- **Doctor**: Full access to all modules
- **Nurse**: Access to patient vitals, notes, and limited appointment management
- **Receptionist**: Manage appointments and basic patient information
- **Pharmacist**: View and fulfill prescriptions

## Customization

The app supports:
- Custom clinic branding
- Customizable prescription templates
- Adjustable appointment durations and buffer times
- Multi-language support (English and Arabic)

## License

This project is licensed for your exclusive use as specified in our agreement.

## Support

For any questions or support needs, please contact the developer.
