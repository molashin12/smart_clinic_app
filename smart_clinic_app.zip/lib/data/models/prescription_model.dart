import 'package:isar/isar.dart';

part 'prescription_model.g.dart';

@collection
class PrescriptionModel {
  Id id = Isar.autoIncrement;
  
  @Index(unique: true)
  late String? firebaseId;
  
  @Index()
  late String patientId;
  
  @Index()
  late String doctorId;
  
  @Index()
  late String clinicId;
  
  late String? recordId;
  
  @Index()
  late DateTime issueDate;
  
  late DateTime? expiryDate;
  late String status; // "active", "completed", "cancelled"
  late List<MedicationModel> medications;
  late String? notes;
  late DateTime? createdAt;
  late DateTime? updatedAt;
  late String? createdBy;
  late String? updatedBy;
  late String? pharmacistId;
  late DateTime? fulfilledDate;
  late DateTime? lastSynced;
  late bool needsSync;

  // Constructor
  PrescriptionModel({
    this.firebaseId,
    required this.patientId,
    required this.doctorId,
    required this.clinicId,
    this.recordId,
    required this.issueDate,
    this.expiryDate,
    required this.status,
    required this.medications,
    this.notes,
    this.createdAt,
    this.updatedAt,
    this.createdBy,
    this.updatedBy,
    this.pharmacistId,
    this.fulfilledDate,
    this.lastSynced,
    this.needsSync = false,
  });

  // Convert from Entity to Model
  factory PrescriptionModel.fromEntity(dynamic entity) {
    return PrescriptionModel(
      firebaseId: entity.id,
      patientId: entity.patientId,
      doctorId: entity.doctorId,
      clinicId: entity.clinicId,
      recordId: entity.recordId,
      issueDate: entity.issueDate,
      expiryDate: entity.expiryDate,
      status: entity.status,
      medications: entity.medications
          .map<MedicationModel>((med) => MedicationModel.fromEntity(med))
          .toList(),
      notes: entity.notes,
      createdAt: entity.createdAt,
      updatedAt: entity.updatedAt,
      createdBy: entity.createdBy,
      updatedBy: entity.updatedBy,
      pharmacistId: entity.pharmacistId,
      fulfilledDate: entity.fulfilledDate,
      lastSynced: DateTime.now(),
      needsSync: false,
    );
  }

  // Convert to Map for Firebase
  Map<String, dynamic> toMap() {
    return {
      'patientId': patientId,
      'doctorId': doctorId,
      'clinicId': clinicId,
      'recordId': recordId,
      'issueDate': issueDate,
      'expiryDate': expiryDate,
      'status': status,
      'medications': medications.map((med) => med.toMap()).toList(),
      'notes': notes,
      'createdBy': createdBy,
      'updatedBy': updatedBy,
      'pharmacistId': pharmacistId,
      'fulfilledDate': fulfilledDate,
    };
  }
}

@embedded
class MedicationModel {
  late String name;
  late String dosage;
  late String frequency;
  late String duration;
  late String? instructions;
  late int quantity;
  late int? refills;

  MedicationModel({
    required this.name,
    required this.dosage,
    required this.frequency,
    required this.duration,
    this.instructions,
    required this.quantity,
    this.refills,
  });

  factory MedicationModel.fromEntity(dynamic entity) {
    return MedicationModel(
      name: entity.name,
      dosage: entity.dosage,
      frequency: entity.frequency,
      duration: entity.duration,
      instructions: entity.instructions,
      quantity: entity.quantity,
      refills: entity.refills,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'dosage': dosage,
      'frequency': frequency,
      'duration': duration,
      'instructions': instructions,
      'quantity': quantity,
      'refills': refills,
    };
  }
}
